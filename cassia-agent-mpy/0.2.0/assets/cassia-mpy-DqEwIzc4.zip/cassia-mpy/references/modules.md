# Everything that is not cassiablue

`cassiasys`, `cassiamqtt`, `cassiacommon`, `aiohttp`, the asyncio subset, and
the modules that are present but undocumented. BLE is in
`references/cassiablue.md`; the gateway's REST API is in
`references/restful.md`.

## cassiasys - identity, and the only writable store

```python
cassiasys.gateway_type() -> str            # "M2000"
cassiasys.gateway_mac() -> str             # "CC:1B:E0:E4:C8:94"
cassiasys.gateway_ver() -> str             # "2.2.mp.2509031847"
cassiasys.save_user_config(config) -> None # str, raises if > 16KB
cassiasys.read_user_config() -> str        # raises on failure; JSON per meta.json
```

Synchronous, no `await`, and the only module here that raises instead of
returning `(ok, result)`. `save_user_config` takes a **string**, so serialise it
yourself, and it is the only durable write on the whole device:

```python
try:
    cfg = json.loads(cassiasys.read_user_config())
except Exception:
    cfg = {}
cfg["last_seen"] = "CC:1B:E0:00:11:22"
cassiasys.save_user_config(json.dumps(cfg))
```

Read it back in a later call before you claim it persisted.

## cassiamqtt

Two client instances at most, and always as a context manager:

```python
async with cassiamqtt.CassiaMQTTClient(uri, username=None, password=None,
        client_id=None, ca=None, cert=None, key=None, key_pass=None,
        cert_common_name=None) as c:
    await c.subscribe(topic, qos=0) -> (ok, result)
    await c.publish(topic, payload, qos=0, retain=False) -> (ok, result)
    await c.unsubscribe(topic) -> (ok, result)
    async for m in c:      # m: topic str, qos int, payload str
```

Iterating the client is another unbounded stream. Bound it, or the call runs to
its timeout every time:

```python
async with cassiamqtt.CassiaMQTTClient("mqtt://10.0.0.9:1883") as c:
    print("sub:", await c.subscribe("gw/#"))
    print("pub:", await c.publish("gw/hello", "from the gateway"))
    async def first():
        async for m in c:
            return (m.topic, m.payload)
    try:
        print("got:", await asyncio.wait_for(first(), 3))
    except asyncio.TimeoutError:
        print("nothing arrived in 3s")
```

## cassiacommon

```python
f = cassiacommon.SimpleFuture()
f.set_result(code, value)
code, value = await f.wait()

q = cassiacommon.AsyncQueue(max_size=16)   # asyncio.Queue does not exist here
q.put_nowait(item)
item = await q.get()

c = cassiacommon.DataCache(max_bytes=262144, hashtable_size=53)
c.info(); c.clear()
await c.put(key, data)
await c.get(key, cnt=10)              # -> list
await c.get_next(cnt=10, flag=False)  # -> list
```

`DataCache` is RAM, not disk: it is gone when the microapp restarts.

## aiohttp - client only

```python
async with aiohttp.ClientSession() as s:
    async with s.get(url) as r:
        print(r.status, await r.text())   # or await r.json()
```

`get` and `post` are the well-trodden pair; `put`, `patch`, `delete`, `head`,
`options` and a generic `request` are all there too. So is a WebSocket client
(`s.ws_connect(url)`, `aiohttp.WSMsgType`), which the published docs do not
mention - useful, but untested here, so probe before you rely on it.

HTTPS out of the gateway works - `ssl` and `tls` both import - contrary to
comments in older Cassia code. The default is HTTP/1.0; a server answering
`426` wants `aiohttp.HttpVersion11`. But **HTTP/1.1 chunked bodies are not
de-chunked**: `resp.content.readline()` hands back the raw hex chunk-length
lines (`c6`, `c8`) mixed into the payload, and stripping them is your problem.
Stay on 1.0 unless the server refuses it.

## The asyncio subset

Present: `Task` / `create_task`, `Event`, `ThreadSafeFlag`, `Lock`, `gather`,
`run`, `sleep`, `sleep_ms`, `wait_for`, `wait_for_ms`, `CancelledError`,
`TimeoutError`, `current_task`, and the stream pair `open_connection` /
`start_server`.

Absent: `Queue` / `LifoQueue` / `PriorityQueue` (use `cassiacommon.AsyncQueue`),
`Semaphore`, `Condition`, `Future` (use `cassiacommon.SimpleFuture`), `shield`,
`timeout`, `wait`, `as_completed`, `to_thread`, `get_running_loop`.

Never call `time.sleep()` in a coroutine. It blocks the gateway's event loop,
including the HTTP server that is answering this very call. Use
`await asyncio.sleep()` or `sleep_ms()`.

## Present but undocumented

`deflate` (decompress only - the firmware was built without the compressor),
`websocket`, `requests` / `urequests`, `btree`, `ssl`, `tls`, `ntptime`, `mip`,
`platform`.

With `deflate.DeflateIO(stream, deflate.RAW)`, pass `wbits=15` explicitly. The
default succeeds on inputs too small to reference the sliding window and then
fails with `OSError(22)` (EINVAL) on real data - a 480-byte test passes, a 3KB
one does not.

## Introspection, when this file is not enough

`dir(obj)` works on every module and instance here, including the C modules
under the wrappers (`cassiabluec`, `cassiamqttc`, `cassiadatacachec`), so
`print(dir(cassiablue))` is a cheap way to check a name exists before writing a
snippet around it.

What you cannot get: signatures. There is no `inspect`, `__doc__` is `None`
everywhere (the firmware is built without docstrings), and `help()` writes to
the hardware console rather than to your captured output. So `dir()` answers
"does this name exist", and this skill answers "how do I call it". Do not try to
discover an argument list on the device.
