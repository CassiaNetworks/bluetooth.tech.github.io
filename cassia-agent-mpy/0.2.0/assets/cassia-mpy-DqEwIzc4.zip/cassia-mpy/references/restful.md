# The gateway's own RESTful API, from inside the microapp

`cassiablue.send_cmd` is the escape hatch: it calls the gateway's local REST API
from your code, so anything the firmware exposes over HTTP but the MicroPython
modules do not wrap is still reachable. No host, no port, no credentials - the
call goes to this gateway from inside it, and the login/session rules of the web
API do not apply.

Reach for it when `cassiablue`, `cassiasys` or `cassiamqtt` has no wrapper. For
scan, connect, GATT and notify, use the wrappers in
`references/cassiablue.md`: they stream, they parse, and they do not make you
handle SSE by hand.

## send_cmd

```python
await cassiablue.send_cmd(path, method="GET", query=None, body=None) -> (ok, result)
```

- `path` - API path, leading slash, no host: `"/cassia/info"`.
- `method` - HTTP method, default `"GET"`.
- `query` - the query string without `?`: `"tag=BT&level=INFO"`.
- `body` - request body as a **string**; serialise JSON yourself.
- `result` - always a string. Parse it with `json.loads` when the endpoint
  answers JSON; several answer bare `OK`.

Measured on an M2000 (firmware 2.2.0.2607062040), microapp mode:

```python
ok, r = await cassiablue.send_cmd("/cassia/memory")
# (True, '{"free-memory":2450588,"free-internel":65883,"free-spiram":2384844}')

ok, r = await cassiablue.send_cmd("/cassia/info", query="fields=container")
# query is appended for you; no '?' in either argument

ok, r = await cassiablue.send_cmd("/cassia/nope")
# (False, 'URL not found')   <- a plain message, not JSON
```

Three failure shapes worth recognising:

- `(False, "URL not found")` - the path does not exist **or** the endpoint does
  not accept that method. The message is the same either way, so do not read it
  as "wrong path".
- `(False, "operation not support")` - the endpoint exists but is not available
  through this channel. `/cassia/getlog` answers this: the log download is a
  binary zip, and `send_cmd` only carries text.
- A raise, not a tuple, for a malformed call. Wrap a probe in `try` when you are
  guessing at a path.

Two things `send_cmd` cannot do. It is one request and one complete response, so
**SSE endpoints do not work** through it - `/gap/nodes?event=1` (the scan
stream), `/gap/rssi`, `/management/nodes/connection-state`,
`/cassia/getlog?event=1`; use the `cassiablue` streams instead. And it returns a
string, so binary bodies (the log zip, firmware images) are out of reach.

Mind the 30s ceiling on `run_python`: an endpoint that is allowed to take longer
than that cannot be awaited to completion here. `/cassia/gps/request` is
documented at up to 50s, so it will lose the race with the timeout even at
`timeout=30`.

## Endpoints

Provenance matters here, so it is marked per row: **[m]** verified on the test
gateway through `send_cmd`, **[s]** transcribed from the Cassia REST API spec,
**[o]** from the operations notes. Only the `[m]` rows have been seen to answer
on this firmware; the others may be missing on your model or firmware, and the
answer for an absent one is `URL not found`.

### Gateway state

| call | notes |
|---|---|
| `GET /cassia/info` **[m]** | the big one. Keys seen: `model`, `version`, `mac`, `name`, `uptime`, `local-api`, `free-memory`, `free-internel`, `free-spiram`, `capwap-ip`, `capwap-state`, `capwap-runtime`, `capwap-uplink`, `capwap-uplinkmac`, `features`, `scan`, `conn_params`, `chip-params`, `ble_power`, `gps`, `https`, `dongle`, `wireless`, `wireless_ap`, `timeconf`, `timezone`, `ac`, `reset_option`, `start`. Note the firmware's own spelling of `free-internel` |
| `GET /cassia/info?fields=container` **[s]** | adds `container.status` and `container.apps[]` on LXC-container firmware. Accepted but with nothing extra to report on this MicroPython build |
| `GET /cassia/memory` **[m]** | `{"free-memory":N,"free-internel":N,"free-spiram":N}`, bytes. Cheaper than `/cassia/info` for a health loop |
| `GET /gatt/features` **[m]** | `{"savegattdb":true,"partition":"nvs"}`. `nvs` means 16MB flash, `reserve` means 4MB |
| `GET /gatt/nodes/rate` **[m]** | BLE uplink rate; `{}` when nothing is connected |

### Logs

| call | notes |
|---|---|
| `GET /cassia/setlog?tag=BT&level=INFO` **[m]** | answers `OK`. Tags are subsystems (`BT`), levels the usual `ERROR`/`WARN`/`INFO`/`DEBUG` |
| `GET /cassia/getlog` **[m, refused]** | `(False, "operation not support")`. It is an encrypted zip download (zip password `Cassia`), and `send_cmd` carries text only. `?size=N` asks for N x 32KB, default 8; `?event=1` is an SSE tail. None of it usable from here - tell the operator to fetch it from the gateway's web UI |

### Bluetooth radio and per-device access

| call | notes |
|---|---|
| `GET /gap/btaddr` **[m]** | `{"nodes":[{"bdaddr":"CC:1B:E0:E4:C8:96","bdaddrType":"public","chipId":0}]}` - one entry per BLE chip. This is the radio's address, and it is not the same as `cassiasys.gateway_mac()` |
| `POST /gap/btaddr` **[o]** | body `{"address":"CC:1B:E0:XX:XX:XX"}`. Rewrites the radio address; do not do this without being asked |
| `GET /gap/nodes?connection_state=connected` **[m]** | `{"nodes":{}}` when nothing is connected - an object, not a list, same quirk as `get_connected_devices()`, which is the wrapper you should normally use |
| `GET /gatt/nodes/{mac}/handle/{handle}/value` **[s]** | read by handle; `{"handle":"36","value":"A00100"}`. `gatt_read` wraps this |
| `GET /gatt/nodes/{mac}/handle/{handle}/value/{hex}` **[s]** | write by handle, over GET, value in the path. `?noresponse=1` for write-without-response. `gatt_write` wraps this |
| `GET /gatt/nodes/{mac}/services/{service_uuid}/characteristics/{char_uuid}/value/{hex}` **[o]** | the same write addressed by UUID instead of handle - useful when a device renumbers handles between connections |
| `GET /gatt/nodes/{mac}/services/characteristics/descriptors` **[s]** | the whole GATT tree in one call; `gatt_discover` wraps this |
| `POST /gap/btcheck` **[o]** | body `{"enable":"1"}` (default) or `{"enable":"0"}` to disable the BLE patch |
| `POST /gap/connection/supervision/overwrite` **[o]** | body `{"supervision_timeout":"10000"}`, milliseconds. Overrides the negotiated supervision timeout for new connections |

### Per-model system controls

Each of these exists on some models only, and each changes how the gateway
behaves. Read the current value first where one is readable, tell the operator
what you are about to change, and do not call them speculatively.

| call | notes |
|---|---|
| `POST /force/country` **[o]** | body `{"country":"US"}`. M2000. Regulatory domain, which moves TX power limits |
| `POST /force/bootmode` **[o]** | body `{"mode":"1"}`. M1500 |
| `GET /cassia/gps/request` **[o]** | M2000. Documented at up to 50s, so it cannot complete inside `run_python`'s 30s ceiling |
| `GET /cassia/wifi_scan/start` **[o]** | M2000. Scans 2.4GHz Wi-Fi to explain BLE interference |
| `GET /gap/channel/assessment?wifi=1` **[s]** | the XE-series equivalent; answers `wifi.results[]` with `ssid`, `bssid`, `channel`, `signal` |

### Do not call these

`/cassia/reboot`, `/cassia/reset`, `/cassia/upgrade`, `/cassia/resetpass`,
`POST /cassia/info` (which changes the web password, sharing a path with the
info read), and the whole `/cassia/container/*` and `/cassia/python/*` families
exist and would be reachable. They restart, wipe or re-flash the device you are
running on - `/cassia/python/stop` stops the microapp that is executing your
code, taking the agent with it. Tell the operator to use the web UI instead.
