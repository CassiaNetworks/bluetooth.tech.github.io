# cassiablue - BLE on the gateway

Scanning, connections, GATT and notifications. Every coroutine here returns
`(ok, result)`; on failure `result` is a plain message string, not JSON. The
exceptions to that rule are in "Starting and stopping" below, and they are the
ones that bite.

Read `references/restful.md` for `cassiablue.send_cmd`, the raw REST channel in
the same module.

## Scanning

```python
await cassiablue.start_scan(query=None) -> (ok, result)
await cassiablue.stop_scan() -> (ok, result)
async for d in cassiablue.scan_result():
    # d: bdaddr, bdaddrType ("public"|"random"), rssi int, evtType int,
    #    name, adData hex str, scanData hex str
```

`query` is a URL query string, and you should always pass one:

| key | example | meaning |
|---|---|---|
| `active` | `active=1` | active scan (asks for the scan response) |
| `filter_name` | `filter_name=Cassia*` | name prefix |
| `filter_mac` | `filter_mac=CC:1B:*` | address prefix |
| `filter_uuid` | `filter_uuid=180d,180f` | service UUIDs, no dashes |
| `filter_rssi` | `filter_rssi=-70` | at least this strong |
| `filter_duplicates` | `filter_duplicates=1000` | ms before repeating a device |
| `connectable` | `connectable=1` | connectable advertisements only |
| `report_interval` | `report_interval=1000` | ms between reports |
| `phy` | `phy=1M,2M,CODED` | PHYs to scan |

The stream never ends by itself. Bound it, always stop the scan, and
deduplicate instead of printing each advertisement. Unnamed devices are
reported with the literal name `(unknown)`.

```python
seen = {}
ok, res = await cassiablue.start_scan("filter_name=Cassia*&active=1")
if not ok:
    print("start_scan failed:", res)
else:
    async def collect():
        async for d in cassiablue.scan_result():
            a = d.get("bdaddr")
            r = d.get("rssi", -127)
            if a not in seen or r > seen[a][0]:
                n = d.get("name") or ""
                seen[a] = (r, "" if n == "(unknown)" else n)
    try:
        await asyncio.wait_for(collect(), 4)
    except Exception:
        pass
    await cassiablue.stop_scan()
for a in sorted(seen, key=lambda k: -seen[k][0])[:20]:
    print("%s  %4d dBm  %s" % (a, seen[a][0], seen[a][1]))
```

The `ble_scan` tool is exactly this. Prefer it for a plain "what is around";
write the loop yourself only when you need a field it drops.

## Starting and stopping

The three streams do not behave alike, and none of these report through `ok` -
they **raise**, which is the one place where checking `ok` is not enough
(measured on M2000, firmware 2.2.mp):

| stream | second start | stop with nothing running |
|---|---|---|
| scan | raises `RuntimeError: Scan already in progress` | raises `RuntimeError: No scan in progress` |
| notify | raises `RuntimeError: Notify already in progress` | raises `RuntimeError: No notify in progress` |
| connection state | `(True, None)`, idempotent | `(True, None)`, idempotent |

So a `stop_scan()` or `stop_recv_notify()` in a cleanup path has to be guarded,
or the cleanup replaces your real error with a traceback:

```python
try:
    await cassiablue.stop_scan()
except Exception:
    pass
```

`start_recv_notify` answers `(True, "OK")`; the other starts and all three
stops answer `(True, None)`. Do not test `result` for a value.

## Connections

```python
await cassiablue.connect(addr, params=None) -> (ok, result)
    # params is a JSON string: '{"type":"random","timeout":5000}'
await cassiablue.disconnect(addr) -> (ok, result)
await cassiablue.get_connected_devices() -> (ok, json_str)
    # {"nodes":[{bdaddrs:{bdaddr,bdaddrType}, id, handle, connectionState,
    #   name, chipId, pairStatus, rssi, packetLossRate, tx_phy, rx_phy}]}
    # {"nodes":{}} when nothing is connected - an object, not an empty list
await cassiablue.start_recv_connection_state() -> (ok, result)
await cassiablue.stop_recv_connection_state() -> (ok, result)
async for e in cassiablue.connection_result():
    # e: connectionState ("connected"|"disconnected"), rssi int,
    #    handle str (the device MAC), reason str, packetLossRate int
```

A device advertising with a random address needs `{"type":"random"}`; without
it the connect times out and says nothing about why. Take the type from the
scan's `bdaddrType`.

## GATT

```python
await cassiablue.gatt_discover(addr) -> (ok, json_str)
    # [{uuid, primary, handle int, characteristics:[{handle int,
    #   properties int, uuid, descriptors:[{handle, uuid}]}]}]
await cassiablue.gatt_read(addr, handle) -> (ok, json_str)
    # handle is a STRING; result {"handle":"44","value":"A00100"}
await cassiablue.gatt_write(addr, handle, value, noresponse=False) -> (ok, result)
    # handle and value are hex STRINGS, e.g. "45", "0100"
```

Mind the asymmetry: `gatt_discover` reports handles as ints, `gatt_read` and
`gatt_write` take them as strings, `notify_result` reports ints again. Convert
explicitly (`str(h)`), or a write addresses nothing and still looks like it
worked.

`properties` is a bitmask: 0x02 read, 0x04 write-without-response, 0x08 write,
0x10 notify, 0x20 indicate. Check it before writing rather than discovering by
timeout that the characteristic is read-only.

## Notifications

```python
await cassiablue.start_recv_notify() -> (ok, result)   # one at a time; raises if one is up
await cassiablue.stop_recv_notify() -> (ok, result)    # raises if none is up
async for n in cassiablue.notify_result():
    # n: id str (the device MAC), dataType ("notification"|"indication"),
    #    handle int, value hex str
```

Enabling notifications is a write to the characteristic's CCCD descriptor:
`"0100"` to notify, `"0200"` to indicate, `"0000"` to turn it off.

### The notify race

A device may push its first notification **before** `gatt_write` returns, so
the obvious order - write the trigger, then start consuming - drops exactly the
packets you were waiting for. Arm the consumer first:

```python
ADDR, CCCD = "CC:1B:E0:00:11:22", "46"
got = []

ok, res = await cassiablue.start_recv_notify()
if not ok:
    print("start_recv_notify failed:", res)
else:
    async def consume():
        async for n in cassiablue.notify_result():
            if n.get("id") == ADDR:
                got.append(n.get("value"))
                if len(got) >= 5:
                    return
    task = asyncio.create_task(consume())
    await asyncio.sleep_ms(20)          # let the consumer arm
    ok, res = await cassiablue.gatt_write(ADDR, CCCD, "0100")
    print("enable notify:", ok, res)
    try:
        await asyncio.wait_for(task, 5)
    except asyncio.TimeoutError:
        pass
    try:
        await cassiablue.stop_recv_notify()
    except Exception:
        pass
print("packets:", len(got), got[:5])
```

`start_recv_connection_state` before `connect` has the same shape and the same
trap.

## Also in this module, undocumented

`start_recv_btmon` / `stop_recv_btmon` / `btmon_result` are an HCI-level
monitor stream in the same start/stream/stop shape as notify. `clear_resource`
and `close_cmd` are teardown helpers the microapp runtime uses. None of these
are covered by the published API docs; treat them as unsupported and reach for
them only when a normal path cannot answer the question.
