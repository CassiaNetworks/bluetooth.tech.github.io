---
name: cassia-mpy
version: 0.2.1
description: The Cassia gateway's MicroPython API as run_python sees it - cassiasys, cassiablue (scan, connect, GATT, notify), cassiamqtt, cassiacommon, aiohttp, and the gateway's own RESTful API through send_cmd - with the firmware's asyncio subset, its traps, and a working recipe for each.
when_to_use: Read this before writing any run_python code beyond a one-line probe. Required for BLE connect / GATT / notify, MQTT, HTTP out of the gateway, calling the gateway's REST API, and persisting configuration, where this firmware differs from CPython in ways that fail silently.
author: Cassia Networks
env: mpy
---

# Cassia gateway MicroPython

This is what `run_python` executes against: MicroPython 1.26.1 inside the
gateway's microapp container, measured on an M2000. It is not CPython, and it
is not a complete MicroPython port either. Where this disagrees with the
published module docs, this was measured.

The short version, in case you read nothing else: every `cassia*` coroutine
returns `(ok, result)` and you have to check `ok`; every stream must be bounded
and stopped; there is no filesystem; annotations and `typing` raise at import;
and printing inside a stream loop hangs the app.

This file is a router: what follows applies to every snippet you send, and the
signatures, result shapes and worked recipes are in the reference files listed
at the end.

This file is written in ASCII on purpose. So is every snippet you send.

## Execution model

Your code is wrapped in an `async def` and awaited, so top-level `await` is
legal. A bare trailing expression reports its value, so
`cassiasys.gateway_type()` on its own is enough; anything else needs `print()`.

Each `run_python` call gets a **fresh namespace**. Nothing you define survives
to the next call, so re-read the state you need or do the whole job in one
call. (The `/terminal` console is the exception - it keeps one namespace so a
human can explore step by step. Your calls are not that.)

Bounds on every call: 5s timeout by default, 30s maximum via the `timeout`
argument, 4096 characters of captured output. Only `await` points are
interruptible, so a long synchronous loop is not stopped by the timeout - it
blocks the gateway's event loop until it finishes, and the call fails anyway.

Already bound, no import needed: `cassiasys`, `cassiablue`, `cassiacommon`,
`cassiamqtt`, `asyncio`, `aiohttp`, `json`, `time`, `gc`, `struct`, `binascii`,
`re`, `math`, `os`. The examples in the reference files rely on that. Import
anything else yourself.

Failures come back as a real traceback with line numbers relative to the code
you sent. Read the number, fix that line; do not resend the same snippet.

## Hard constraints

**ASCII only.** Source must be 0x00-0x7F, comments and strings included: no
CJK, smart quotes, em dash, ellipsis, non-breaking space, BOM.

**No annotations.** `list[int]` and `dict[str, int]` (PEP 585) and `str | None`
(PEP 604) raise `TypeError` at import. Drop annotations entirely. Also absent:
`typing`, `dataclasses`, `pathlib`, `subprocess`, `concurrent.futures`,
`contextvars`, `machine`, `network`, `_thread`.

**No filesystem.** `os.listdir()` is empty, `statvfs` is all zeros, and
`open(p, "w")` / `os.mkdir` / `os.rename` raise `OSError(ENODEV)`. The only
durable store is `cassiasys.save_user_config`, 16KB of string.

**Check `ok`.** Every `cassia*` coroutine returns `(ok, result)`. On failure
`result` is a plain message string, not JSON, and the call itself did not
raise - so code that ignores `ok` reports success it never had.

**Do not print per event.** One `print` per scan result, notification or tick
back-pressures the small stdout buffer and hangs the app. Sample one in N,
print on change, or aggregate and print once at the end.

**Stop what you start.** A scan, notify or connection-state stream left running
keeps consuming gateway resources after your call returns. Always call the
matching `stop_*`, and bound every `async for` with a counter or
`asyncio.wait_for`.

**No `time.sleep()` in a coroutine.** It blocks the gateway's event loop,
including the HTTP server answering this very call. Use `await asyncio.sleep()`
or `sleep_ms()`.

**`del bytearray[:n]` raises** `TypeError: 'bytearray' object doesn't support
item deletion`. Build a fresh bytearray instead of slicing one in place.

## Where the detail is

Three reference files. Paths below are relative to this skill's directory,
which is the `[dir: ...]` line above this body - `read_file` wants the two
joined, e.g. `/skills/cassia-mpy/references/cassiablue.md`.

| file | read it for |
|---|---|
| `references/cassiablue.md` | BLE: scanning and its filter keys, connect/disconnect, connected-device state, GATT discover/read/write, notifications and the notify race |
| `references/modules.md` | everything else on the device: `cassiasys` config store, `cassiamqtt`, `cassiacommon` (queue, future, cache), `aiohttp`, the asyncio subset, and modules that exist but are undocumented |
| `references/restful.md` | `cassiablue.send_cmd` and the gateway's own REST endpoints: info, memory, flash features, logs, BT address, per-model system controls |

Read the one you need before you write the code, not after the first failure:
a guessed signature costs a call, a traceback and a retry.
