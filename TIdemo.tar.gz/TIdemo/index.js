// const debug = require('debug')('lexpress');
const co = require('co');
const api = require('./js/api')('http://192.168.199.188');
const hub = new api.Hub();
// const utils = require('./js/utils');
const profile = require('./js/profile')();
const AzureMessage = require('./js/azure-message');

const area = {

};


start();

hub.on('scan', (data) => {
	let _data = JSON.parse(data);
	if (!profile.filter(_data)) {
		return;
	};
	let deviceMac = _data.bdaddrs[0].bdaddr;
	let type = _data.bdaddrs[0].bdaddrType;
	connect(deviceMac, type);
});
hub.on('notify', (data) => {
	// console.log('nnnnnnnnnnnn',data);
	const date = new Date();
	const _data = JSON.parse(data);
	let deviceMac = _data.id;
	if (area[_data.id]) {
		let res = profile.notifyParse(_data);
		console.log(`-------------时间： ${date}, data：${res}----------`);
		// AzureMessage.send('message', res, (err, msgRes) => {
		// 	console.log(msgRes);
		// });
	}
});
hub.on('connectionStatus', (data) => {
	// console.log('cccccccccccc',data);
});

function start() {
	console.log('application start');
	hub.scan();
	hub.notify();
	hub.connectionStatus();
}

function connect(deviceMac, type) {
	if (hub.isConnecting || Date.now() - hub.lastConnection <= 5000) {
		return;
	}
	hub.isConnecting = true;
	hub.lastConnection = Date.now();
	if (!area[deviceMac]) {
		area[deviceMac] = {
			'deviceMac': deviceMac
		};
	}
	hub.connect(deviceMac, type).then(function() {
		hub.isConnecting = false;
		write(deviceMac);
	}).catch(function(err) {
		hub.isConnecting = false;
	});
}

function write(deviceMac) {
	let writeValue = profile.openAll();
	co(function*() {
		try {
			for (let item of writeValue) {
				hub.writeByHandle(deviceMac, item.handle, item.value).catch(function(err) {
					throw new Error("writeFail");
				});
			}
		} catch (e) {
			console.log('TI-写入指令失败', e);
			hub.disconn(deviceMac);
		}
	});
}