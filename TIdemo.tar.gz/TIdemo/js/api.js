 module.exports = function(address) {
 	const EventEmitter = require('events');
 	const request = require('request');
 	const querystring = require('querystring');
 	const EventSource = require('./eventsource');

 	const req = request.defaults({
 		baseUrl: address,
 		timeout: 10000,
 		json: true,
 	});

 	class Hub extends EventEmitter {
 		constructor() {
 			super();
 			this.notifyEs = null;
 			this.scanEs = null;
 			this.leNotifyEs = null;
 			this.isConnecting = false;
			this.lastConnection = 1;

 			// this.on('newListener', (eventName) => {
 			//   switch (eventName) {
 			//     case 'notify':
 			//       this.notifyEs = this.listenNotify();
 			//       break;
 			//     case 'scan':
 			//       this.scanEs = this.scan();
 			//       break;
 			//     case 'statusNotify':
 			//       this.leNotifyEs = this.statusNotify();
 			//       break;
 			//   }
 			// });
 			// this.on('removeListener', (eventName) => {
 			//   const count = this.listenerCount(eventName);

 			//   switch (eventName) {
 			//     case 'notify':
 			//       if (!count) {
 			//         this.notifyEs && this.notifyEs.close();
 			//         this.notifyEs = null;
 			//         debug(address, this.mac, 'removeListener stop notify');
 			//       }
 			//       break;
 			//     case 'scan':
 			//       if (!count) {
 			//         this.scanEs && this.scanEs.close();
 			//         this.scanEs = null;
 			//         debug(address, this.mac, 'removeListener stop scan');
 			//       }
 			//       break;
 			//     case 'statusNotify':
 			//       if (!count) {
 			//         this.leNotifyEs && this.leNotifyEs.close();
 			//         this.leNotifyEs = null;
 			//         debug(address, this.mac, 'removeListener stop leNotifyEs');
 			//       }
 			//       break;
 			//   }
 			// });
 			// this.on('offline', () => {
 			//   this.emit('error', 'offline');
 			// });
 		}

 		scan(option = {
 			active: 1
 		}) {
 			const self = this;
 			const query = querystring.stringify(option);
 			const es = new EventSource(`${address}/gap/nodes?event=1&${query}`, {
 				timeout: 60000
 			});

 			es.onmessage = function(e) {
 				// console.log('scan', e);
 				self.emit('scan',e.data);
 				// const obj = {

 				// }
 				// api.emit('scan', obj);
 			};

 			es.onerror = function(e) {
 				console.log('scan err:', e);
 			};


 		}

 		notify() {
 			let self = this;
 			const es = new EventSource(`${address}/gatt/nodes?event=1`, {
 				timeout: 60000
 			});
 			es.onmessage = function(e) {
 				// console.log('nofity:', e);
 				self.emit('notify',e.data);
 				// if (e.data.match('keep-alive')) {
 				//   return;
 				// };
 				// self.emit('notify', {
 				//   origin: e.data,
 				//   timestamp: e.timestamp
 				// });
 			};
 			es.onerror = function(e) {
 				console.log('notify err', e);
 			};
 		}

 		connectionStatus() {
 			let self = this;
 			const es = new EventSource(`${address}/management/nodes/connection-state?`, {
 				timeout: 60000
 			});
 			es.onmessage = function(e) {
 				// console.log('connectionStatus:', e);
 				self.emit('connectionStatus',e.data);
 				// if (e.data.match('keep-alive')) {
 				//   return;
 				// }
 				// self.emit('statusNotify', {
 				//   origin: e.data,
 				//   timestamp: e.timestamp
 				// });

 			};
 			es.onerror = function(e) {
 				self.emit('connectionStatus err', e);
 			};


 		}

 		connect(deviceMac, type) {
 			return new Promise((resolve, reject) => {
 				req.post('/gap/nodes/' + deviceMac + '/connection?chip=0', {
 					body: {
 						'type': type || 'public',
 						'timeout': 7000
 					}
 				}, function(err, res, body) {
 					if (err) {
 						console.log('connect err:', err, 'deviceMac:', deviceMac);
 						return reject(err);

 					}
 					if (res && res.statusCode === 200) {
 						console.log('connect success:', deviceMac);
 						return resolve();

 					}
 					console.log('connect fail');
 					return reject(`${body}-${res.statusCode}`);
 				});
 			});
 		}



 		disConn(deviceMac) {
 			return new Promise((resolve, reject) => {
 				req.delete('gap/nodes/' + deviceMac + '/connection', {

 				}, function(err, res, body) {
 					if (err) {
 						console.log('disConnect err:', err, 'deviceMac:', deviceMac);
 						return reject(err);
 					}
 					if (res) {
 						const statusCode = res.statusCode;
 						if (statusCode === 200 || body === 'device not found') {
 							console.log('disConnect success:', deviceMac);
 							return resolve(body);
 						} else {
 							console.log('disConnect fail:', 'deviceMac:', deviceMac);
 							return reject(body);
 						}
 					} else {
 						console.log('disConnect fail', 'deviceMac:', deviceMac);
 					}

 				});

 			});
 		}

 		writeByHandle(deviceMac, handle, value) {
 			return new Promise(function(resolve, reject) {
 				req.get(`/gatt/nodes/${deviceMac}/handle/${handle}/value/${value}`, {}, function(err, res, body) {
 					if (err) {
 						console.log('writeByHandle err:', err, 'deviceMac:', deviceMac, handle, value);
 						return reject(body);
 					};
 					if (res && res.statusCode !== 200) {
 						console.log('writeByHandle fail:', err, 'deviceMac:', deviceMac, handle, value);
 						if (body === 'device not found' || body === 'device disconnect') {}
 						return reject('device not found');
 					}
 					console.log('writeByHandle success:', 'deviceMac:', deviceMac, handle, value);
 					return resolve(body);
 				});
 			});
 		}

 		getConnectedList() {
 			return new Promise(function(resolve, reject) {
 				req.get('/gap/nodes/', {
 					timeout: 7000,
 					qs: {
 						'connection_state': 'connected'
 					}
 				}, function(err, res, body) {
 					if (err) {
 						console.log('get connected devices err', body);
 						return reject(err);
 					};
 					if (res && res.statusCode !== 200) {
 						console.log('get connected devices err', body);
 						return reject(`${body}-${res.statusCode}`);
 					};
 					console.log('get connected success', model, self.mac, body);
 					if (Array.isArray(body.nodes)) {
 						resolve([body, body.nodes.map((item) => {
 							return {
 								name: undefined,
 								type: item.type,
 								node: item.id,
 								chip: item.chipId
 							};
 						})]);
 					} else {
 						resolve([body, []]);
 					}
 				});
 			});
 		}
 	}
 	return {
 		'Hub':Hub
 	};
 };