/*
	crearte by guangyan 2018/5/17 

	TI sensor profile
*/
module.exports = function(address) {


	const baseName = 'TI_CC2650';

	function filter(data) {
		// const data = req.data;
		// if (data.baseName === baseName) {
		//   return true;
		// }
		if (data.name && data.name.match('CC2650')) {
			// data.baseName = baseName;
			return true;
		}
	};


	function notifyParse(data) {
		const date = Date.now();
		let handle = data.handle;
		let value = data.value;
		let deviceMac = data.id;
		const resObj = {
			'deviceMac': deviceMac,
		};

		switch (handle) {
			case 36:// 红外温度
				let temperature = _infraredTemperatureParse(value);
				// console.log('红外温度：', temperature, '时间戳：', date);
				resObj.type = 'temperature';
				resObj.data = temperature;
				break;
			case 44: // 湿度
				let humidity = _humidityParse(value);
				// console.log('湿度：', humidity, '时间戳：', date);
				resObj.type = 'humidity';
				resObj.data = humidity;
				break;
			case 52: // 气压
				let pressure = _pressureParse(value);
				// console.log('气压：', pressure, '时间戳：', date);
				resObj.type = 'pressure';
				resObj.data = pressure;
				break;
			case 68: // 光感
				let optical = _opticalParse(value);
				// console.log('光感', optical, '时间戳：', date);
				resObj.type = 'optical';
				resObj.data = optical;
				break;
			case 60: // 三轴等
				let gyroarr = _gyroscopeParse(value);
				let accarr = _accelerometerParse(value);
				let magarr = _magnetometerParse(value);
				let temp = {
					'gyroscope': gyroarr,
					'accelerometer': accarr,
					'magnetometer': magarr
				};
				// console.log('陀螺仪：', gyroarr, '时间戳：', date);
				// console.log('加速度：', accarr, '时间戳：', date);
				// console.log('磁力计：', magarr, '时间戳：', date);

				resObj.type = 'movement';
				resObj.data = temp;
				break;


		}
		/*
			{"value":"6e0c00918601","handle":52,"id":"24:71:89:E8:8D:07","dataT
			ype":"notification"}
		*/
		return resObj;

	};

	//红外温度传感器
	function _infraredTemperatureParse(tmpData) {
		let SCALE_LSB = 0.03125;
		let rawAmbTemp = parseInt(tmpData.slice(2, 4) + tmpData.slice(0, 2), 16);
		let rawObjTemp = parseInt(tmpData.slice(6, 8) + tmpData.slice(4, 6), 16);
		let anmtemp = (rawAmbTemp >> 2) * SCALE_LSB;
		let objtemp = (rawObjTemp >> 2) * SCALE_LSB;
		return anmtemp;
	}
	//湿度传感器
	function _humidityParse(hdcData) {
		let rawTemp = parseInt(hdcData.slice(2, 4) + hdcData.slice(0, 2), 16);
		let rawHum = parseInt(hdcData.slice(6, 8) + hdcData.slice(4, 6), 16);
		//  - 计算温度[°C] 
		let temp = rawTemp / 65536 * 165 - 40;
		//  - 计算相对湿度[％RH] 
		let hum = rawHum / 65536 * 100;
		return hum;
	}
	//气压传感器
	function _pressureParse(bmpData) {
		let rawTemp = parseInt(bmpData.slice(4, 6) + bmpData.slice(2, 4) + bmpData.slice(0, 2), 16);
		let rawPa = parseInt(bmpData.slice(10, 12) + bmpData.slice(8, 10) + bmpData.slice(6, 8), 16);

		let temp = rawTemp / 100;
		let pa = rawPa / 100;
		return pa;
	}
	//光学传感器
	function _opticalParse(optData) {
		let data = parseInt(optData.slice(2, 4) + optData.slice(0, 2), 16)
		let e, m;
		m = data & 0x0FFF;
		e = (data & 0xF000) >> 12;
		/** e在4位存储在16位无符号=>它可以存储2 <<（e  -  1）与e <16 */
		e = (e == 0) ? 1 : 2 << (e - 1);
		return m * (0.01 * e);
	}

	//df09 5efe 1f02 7001 2909 94ef 52ff 76ff 65fe
	//Gyro - x  y  z -
	// 陀螺仪
	function _gyroscopeParse(data) {
		let gyroXdata = parseInt(data.slice(2, 4) + data.slice(0, 2), 16);
		let gyroYdata = parseInt(data.slice(6, 8) + data.slice(4, 6), 16);
		let gyroZdata = parseInt(data.slice(10, 12) + data.slice(8, 10), 16);
		let gyroX = parseFloat((gyroXdata * 1) / (65536 / 500)).toFixed(1);
		let gyroY = parseFloat((gyroYdata * 1) / (65536 / 500)).toFixed(1);
		let gyroZ = parseFloat((gyroZdata * 1) / (65536 / 500)).toFixed(1);
		gyroX = gyroX > 255 ? 255 - gyroX : gyroX;
		gyroY = gyroY > 255 ? 255 - gyroY : gyroY;
		gyroZ = gyroZ > 255 ? 255 - gyroZ : gyroZ;
		return [gyroX, gyroY, gyroZ];
	}

	// Acc - x  y  z -
	// 加速度
	function _accelerometerParse(data, range) {
		if (!range) range = 2;
		let accXdata = parseInt(data.slice(14, 16) + data.slice(12, 14), 16);
		let accYdata = parseInt(data.slice(18, 20) + data.slice(16, 18), 16);
		let accZdata = parseInt(data.slice(22, 24) + data.slice(20, 22), 16);
		let accX = parseFloat((accXdata * 1) / (32760 / range)).toFixed(1);
		let accY = parseFloat((accYdata * 1) / (32760 / range)).toFixed(1);
		let accZ = parseFloat((accZdata * 1) / (32760 / range)).toFixed(1);
		accX = accX > range ? range - accX : accX;
		accY = accY > range ? range - accY : accY;
		accZ = accZ > range ? range - accZ : accZ;

		return [accX, accY, accZ];
	}

	// mag - x  y  z -
	// 
	function _magnetometerParse(data) {
		let magX = parseInt(data.slice(16, 18) + data.slice(14, 16), 16);
		let magY = parseInt(data.slice(20, 22) + data.slice(18, 20), 16);
		let magZ = parseInt(data.slice(24, 26) + data.slice(22, 24), 16);
		return [magX * 1.0, magY, magZ];
	}


	function openTemperature() {
		return [{
			'handle': 37,
			'value': 0100,
		}, {
			'handle': 39,
			'value': 01,
		}];
	};

	function openHumidity() {
		return [{
			'handle': 45,
			'value': 0100,
		}, {
			'handle': 47,
			'value': 01,
		}];
	}

	function openMovement() {
		return [{
			'handle': 61,
			'value': 0100,
		}, {
			'handle': 63,
			'value': 'FF00',
		}];
	}

	function openBarometricPressure() {
		return [{
			'handle': 53,
			'value': 0100,
		}, {
			'handle': 55,
			'value': 01,
		}];
	}

	function openOptical() {
		return [{
			'handle': 69,
			'value': 0100,
		}, {
			'handle': 71,
			'value': 01,
		}];
	}

	function openAll() {
		return [{
			'handle': '37',
			'value': '0100'
		}, {
			'handle': '39',
			'value': '01'
		}, {
			'handle': '45',
			'value': '0100'
		}, {
			'handle': '47',
			'value': '01'
		}, {
			'handle': '53',
			'value': '0100'
		}, {
			'handle': '55',
			'value': '01'
		}, {
			'handle': '69',
			'value': '0100'
		}, {
			'handle': '71',
			'value': '01'
		}, {
			'handle': '61',
			'value': '0100'
		}, {
			'handle': '63',
			'value': 'FF00'
		}, ];
	}

	return {
		filter,
		openTemperature,
		openHumidity,
		openMovement,
		openBarometricPressure,
		openOptical,
		openAll,
		notifyParse
	};

};