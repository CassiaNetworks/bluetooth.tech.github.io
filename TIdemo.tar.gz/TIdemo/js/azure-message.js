﻿// Load Azure Client
let iotClient = require("../config/azure-client");
let Message = require('azure-iot-device').Message;

let AzureConfig = require("../config/azure-config.json");

let send = (msgType, msg, callback) => {
	var data = JSON.stringify({
		deviceId: AzureConfig.deviceId,
		data: msg
	});
	var message = new Message(data);
	message.properties.add(msgType, 'true');
	iotClient.sendEvent(message, (err, res) => {
		callback(err, res);
	});
};

let azureMessage = {
	send: send
};


module.exports = azureMessage;