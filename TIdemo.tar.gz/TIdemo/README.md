# TIdemo文档
## 简介
- 程序运行后自动开启scan和notify，当扫描到TI sensor(设备名字包含 "CC2650")的时候进行连接。连接成功后写入指令，如果有一条指令写入失败则断开连接。最终将传感器数据发送至目标server

## 数据格式
###  1. ```红外温度传感器```
#### 单位： ℃
```
 result:{
  deviceMac: 'AA:AA:AA:AA:AA:AA',
  type: 'temperature'
  data: '28.35',
} 
```
###  2. ```湿度传感器```
#### 单位： rh%
```
 result:{
  deviceMac: 'AA:AA:AA:AA:AA:AA',
  type: 'humidity'
  data: '28.35',
} 
```
###  3. ```气压传感器```
#### 单位： kPa
```
 result:{
  deviceMac: 'AA:AA:AA:AA:AA:AA',
  type: 'pressure'
  data: '1000.1',
} 
```
###  4. ```光感感器```
#### 单位： lux
```
 result:{
  deviceMac: 'AA:AA:AA:AA:AA:AA',
  type: 'optical'
  data: '96.2',
} 
```
###  5. ```运动传感器```
#### 单位(gyroscope/陀螺仪)：°/S
#### 单位(accelerometer/加速度)：m/s²
#### 单位(magnetometer/磁力计)：uT
#### 陀螺仪、加速度、磁力计的数据顺序皆为X轴、Y轴、Z轴;
```
 result:{
  deviceMac: 'AA:AA:AA:AA:AA:AA',
  type: 'movement'
  data: {
	gyroscope：[1.5, 2.4, -200],
	accelerometer:[0.0, 0.0, 0.2],
	magnetometer:[29441, 40449, 14]
  },
} 
```