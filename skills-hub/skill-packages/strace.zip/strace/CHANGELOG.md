# Changelog

## 1.0.0 - 2026-07-17

- Initial release: bundled armhf `strace` for the gateway, for tracing a process's system calls and signals (missing files, permission/network failures, syscall hangs).
- Note: the binary is dynamically linked (`ld-linux-armhf.so.3`) and relies on the gateway's own runtime libraries; it only runs on the gateway.
- Documented the non-obvious pitfalls: `-p` attach streams until interrupted (bound it with `timeout`), trace output goes to stderr (use `-o`), and ptrace permission (`ptrace_scope`).
