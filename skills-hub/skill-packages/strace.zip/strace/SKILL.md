---
name: strace
category: debug
description: Bundled strace syscall tracer for the gateway. Trace the system calls a process makes—which files/config/sockets it touches and why a call fails (ENOENT, EACCES, connection refused). Use when the user says "can't find the file / permission denied / can't connect / what is it doing / which config does it read / stuck on some syscall / trace syscalls / attach strace to pid".
when_to_use: When you need to see the system calls and signals of a running or launched process on the gateway—diagnosing missing files, permission errors, network failures, or a process hung in a syscall. Complements gdb (which inspects the stack/crash).
allowed-tools: [read_file, search_files, run_shell]
env: gateway
version: 1.0.0
author: Cassia Networks <https://www.cassianetworks.com>
icon: assets/icon.png
public: true
---

# strace — syscall tracer (gateway)

Bundled `scripts/strace` (armhf, dynamically linked, **gateway only**). First use: `chmod +x scripts/strace`.
If `./scripts/strace -V` fails with a missing `.so`, the gateway lacks that runtime lib—stop and report it.

Environment-specific notes (standard strace usage assumed):

- Attaching with `-p <pid>` streams until interrupted—always bound it (e.g. `timeout`) or it hangs the shell:

```bash
timeout 5 ./scripts/strace -f -p <pid> -e trace=file,network -o /tmp/trace.log
```

- Trace output goes to stderr; use `-o <file>` to capture it cleanly (don't mix with the target's own output).
- Attach needs ptrace rights (same user as target, or root); a non-zero `ptrace_scope` can block it.
