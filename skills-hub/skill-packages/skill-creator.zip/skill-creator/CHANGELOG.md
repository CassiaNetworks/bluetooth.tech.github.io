# Changelog

## 1.0.1 - 2026-07-17

- Imported into Skills Hub from the agent-core builtin (`skills-builtin/skill-creator`).
- Adapted frontmatter to hub conventions: added `category: meta` and `author`, switched the icon to a hub-style PNG. `env` is intentionally left empty—this is a general authoring skill with no runtime dependency.
- Body and `references/skill-authoring.md` are unchanged from the builtin.
