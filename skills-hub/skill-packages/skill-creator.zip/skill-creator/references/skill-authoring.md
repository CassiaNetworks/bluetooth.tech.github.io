# Skill Authoring Guide (agent-core)

This guide consolidates the engineering best practices for skills. Use it together with the
`skill-creator` skill and the `SkillRegistry` lint. Goal: make every skill a **reliable,
low-cost, least-privilege** workflow.

## 1. Three-Tier Progressive Disclosure

Model context is expensive; a skill's value lies in "load on demand":

- **Tier-1 metadata**: `name` + `description` (+ `when_to_use`). Always injected into the skill manifest
  in the system prompt, so the model can decide "whether to use one, and which one". **Must be short with
  strong trigger terms.**
- **Tier-2 body**: the body of `SKILL.md`. Loaded only when the model calls `read_skill <name>`. The body
  should be a **router**: explain the steps and interpretation, and link long detail out to Tier-3.
- **Tier-3 resources**: module docs under `references/`, scripts under `scripts/`, and reference material
  under `docs/`. The body reads them via `read_file` / `search_files` **on demand** — do not dump them all
  into context at once.

> agent-core has merged each skill directory into the **read-only roots** of `OsPolicy`, so `references/`
> and module files can be read via `read_file`/`search_files` even when they are not within `os_allow_roots`
> (but they are not writable).

## 2. Write the Body as a "Router" and Control Line Count

- The body focuses on: **what to do, in what order, how to interpret results, when to hand off to another skill**.
- Line count thresholds (lint will hint):
  - `> 300` lines: consider splitting, move detail to `references/xxx.md`.
  - `> 500` lines: hard warning. An overly long body crowds context and dilutes attention.
- Splitting approach: keep "index + interpretation" in the body, split detail by topic into files under
  `references/`, with one line on "when to read which".

## 3. `description` Is the Key to the Router

The model can only see Tier-1. A poorly written `description` = the skill is never selected.

- State the **trigger scenarios and symptoms** clearly, with words the user might say (trigger terms).
- Use `when_to_use` to supplement "when to use", complementary to `description` rather than duplicating it.
- Bad example: `description: handle channel issues` (too vague).
- Good example: `description: channel never goes READY, stuck in init/registration. Use when the user says "the channel won't start / keeps spinning / connected but no data".`

Naming convention (lint checks): `^[a-z0-9-]{1,64}$`, not starting or ending with `-`. Prefer
`domain-action-object`, e.g. `ontrak-query-status`, `ontrak-cold-start-diagnosis`.

## 4. Least Privilege: `allowed-tools` (Escalation Gate + Cache-Friendly)

`allowed-tools` is an **escalation gate**, not an exclusive whitelist. The constraint is at the **execution
layer**, not "removing tools from the model's manifest":

- **The dispatch layer escalates by risk**: after a skill is activated (`read_skill` succeeds), tools in the
  list (plus `read_skill`/`ask_user`) execute under the normal risk policy; tool calls **outside** the list
  are not hard-rejected — those with Safe risk (read-only, whitelisted commands, writes to safe directories)
  are allowed directly, while anything above Safe must be confirmed by the user before executing. The
  declaration expresses "which tools this skill expects to use", not "lock down all other tools".
- **The tool set stays constant and complete for the model (prompt-cache friendly)**: the `tools` array
  exposed to the model **does not change with the skill**. Prompt cache is strict prefix matching, in the
  order `tools → system → messages`; once you filter `tools` per skill, every activation/switch busts the
  cache of `tools + system (including manifest) + all history messages`. So we keep `tools` constant and only
  escalate by risk at the execution layer; `allowed-tools` softly hints the model which tools to use via the
  `read_skill` result (which lives in the messages stream, not in the cache prefix).
- **Persists across turns + `/reset` exit**: the activation state **persists across turns** (stored in the
  session) until the model reads another skill, or exits explicitly. To exit: call `read_skill` with `name`
  set to the reserved word **`reset`** (or `none`) — this clears the current skill and restores all tools
  (the frontend `/reset`, `/none` expand into this instruction). This preserves multi-turn continuity while
  not "locking down" the whole session with a single skill's whitelist.
- **Reserved names**: `reset` / `none` are reserved parameters of `read_skill` (case- and whitespace-insensitive)
  and cannot be used as real skill names.
- Therefore: **declare on demand**. Give read-only diagnosis skills `[read_file, search_files, run_shell]`;
  add `write_file`/`edit_file` only for those that need write operations. Safe tools outside the declaration
  still work, but risky operations interrupt the flow to wait for user confirmation — list all the tools you
  expect to use for the smoothest experience. Leaving it empty means no restriction.

## 5. Four Script Principles (`scripts/`)

Distill deterministic, fixed-step actions into scripts, so the model "invokes" them instead of improvising
commands on the spot:

1. **Self-healing**: the script itself handles common prerequisites (create missing directories, install
   missing dependencies or fail with a clear error); do not leave the model to patch things up.
2. **Structured output**: output JSON / explicit `key: value` for easy parsing and interpretation by the
   model, avoiding regex scraping of free-form text.
3. **Idempotent**: repeated execution yields the same result with no stacked side effects (e.g. "ensure it
   exists" rather than "create it"). Only then is retry-on-failure safe.
4. **Safety boundaries**: declare dangerous operations explicitly, make them previewable (dry-run), validate
   inputs; destructive actions should preview first, then be confirmed by the user.

Put scripts in `scripts/`; in the body, state clearly "when to run, parameters, expected output". The scripts
themselves are readable via the read-only root and executed via `run_shell` (subject to command confirmation /
whitelist).

## 6. Snapshotting Parameters and Persisting Preferences

- **Snapshot parameters**: confirm and record, once at the start, the values used repeatedly in a task
  (device number, channel, time window), and reuse them in later steps to avoid re-asking.
- **Persist preferences**: preferences the user has stated explicitly (default channel, common thresholds)
  should be stored somewhere reusable in the session, and reused directly next time. Do not ask from scratch
  every time.

## 7. Frontmatter Field Reference

```yaml
---
name: my-skill                 # required; ^[a-z0-9-]{1,64}$
description: one-line trigger…  # required; write trigger terms/symptoms/scenarios
when_to_use: when to use…       # optional; complementary to description
allowed-tools: [read_file, run_shell]  # optional but strongly recommended; pre-authorized set, safe tools outside the list still work, risky tools need user confirmation
argument-hint: "[channel] [--verbose]" # optional; parameter hint in the / command palette
version: 1.0.0                  # optional; shown in the manifest footer / /api/skills / logs
author: John Doe <john@example.com> # optional; author/maintainer. Convention `name <email or link>`; the detail page treats a trailing <…> as email/link
user-invocable: true           # optional (default true); false = model only, not in the / palette
disable-model-invocation: false # optional (default false); true = excluded from the model manifest, the model cannot auto-select it, only the user can trigger it by name
env: gateway, container        # optional; target runtime environment (open vocabulary, recommended ac / gateway / container / pc). **Empty = any environment (do not set for general skills)**; declare only when the skill depends on a specific runtime (dedicated CLI, local service, fixed path) — an environment mismatch is hard-blocked when installing from an online repo
icon: assets/icon.svg          # optional; skill icon (an image relative to the skill directory, or place it at assets/icon.* for auto-detection)
---
```

## 7a. Skills Hub Publishing Fields (this repo)

When a skill is published through the **Skills Hub** in this repo (scanned by `scripts/generate-skills.js`
into `public/skills.json`), a few extra conventions apply on top of the fields above. These are hub
extensions; agent-core ignores unknown frontmatter, so they are harmless elsewhere.

```yaml
category: tool                 # page classification the hub reads from frontmatter (agent-core only uses the directory). Drives the home-page filter tabs; falls back to the grouping dir, or `general` when flat
public: true                   # true = include in the external whitelist build (PUBLIC_ONLY=1 → downloadable public zip). Absent/other = internal only. The deployed landing site always shows all skills regardless
icon: assets/icon.png          # hub skills ship a 256x256 PNG app icon here (not the 24x24 SVG in §7); keep the shared navy/flat style for visual consistency
author: Cassia Networks <https://www.cassianetworks.com>  # shown on the detail page
```

- **`CHANGELOG.md`** — an optional file at the skill root (`skills/<name>/CHANGELOG.md`). The hub renders it
  on the skill detail page. It is standard changelog markdown, not a separate metadata file.
- **Regenerate after any change**: run `node scripts/generate-skills.js` from the repo root so
  `public/skills.json` (and the per-skill zip / icon / assets) is rebuilt.

## 8. Observability and Validation

- **Manifest visibility**: `GET /api/skills` returns all skills (including the fields above) and **discovery
  diagnostics** (`parse_error` for parse failures / `shadowed` for name shadowing / `lint` for authoring
  warnings), no longer silently swallowed.
- **Per-turn structured logs**: every tool call logs `skill_stat skill=… tool=… result=… elapsed_ms=…`;
  set the environment variable `AGENT_SKILL_STATS_FILE=<path>` to persist these records as JSONL for offline
  analysis.
- **Local validation (lint)**: when `SkillRegistry` scans, it runs lint on each skill, and warnings are exposed
  via the `diagnostics` (kind=`lint`) of `/api/skills`:
  - Valid name (`^[a-z0-9-]{1,64}$`), non-empty description ≤1024 chars, body line count thresholds (>300 hint / >500 hard warning).
  - **Reference check**: whether the files referenced by `references/…`, `scripts/…` in the body actually exist (resolved relative to the skill directory).
  - **`allowed-tools` tool name check**: tools in the whitelist must be registered tools (`read_skill`/`ask_user`
    are always available and are never falsely flagged), to catch typos that "silently shrink the tool set".

## 9. Directory Structure Convention

```
skills/
  <category>/            # optional grouping directory (diagnose/ operate/ …)
    my-skill/
      SKILL.md           # Tier-1 + Tier-2 (router body)
      CHANGELOG.md       # optional; rendered on the Skills Hub detail page
      references/        # Tier-3 detail docs, read_file/search_files on demand
        deep-dive.md
      scripts/           # Tier-3 scripts, satisfying the four principles
        do-thing.sh
      assets/            # optional; static resources such as icon.svg
        icon.svg
```

Skills with the same name are **first-come-first-served** in scan order; shadowed ones are listed in the
`/api/skills` diagnostics (including their source directory).
