---
name: skill-creator
category: meta
description: Scaffold a new agent skill the right way — generate SKILL.md frontmatter + router body, references/ and scripts/ layout, least-privilege allowed-tools, and run the authoring checklist. Use when the user says "create/write/author a new skill", "add a skill for X", or asks how to structure a skill.
when_to_use: The user wants to create, scaffold, or review a new skill (SKILL.md), or asks how skills should be structured and what frontmatter to use.
allowed-tools: [read_file, search_files, write_file, run_shell]
argument-hint: "[skill-name]"
version: 1.0.1
author: Cassia Networks <https://www.cassianetworks.com>
icon: assets/icon.png
public: true
---

# Create a New Skill (Scaffold)

This skill turns the best practices in `references/skill-authoring.md` into an executable
set of steps. **Read the guide first, then act.**

Step 0: `read_file references/skill-authoring.md` (the full best practices). To look up a single
point, use `search_files` to search for keywords in that file.

## Steps

1. **Confirm goal and naming**
   - Ask in one sentence: what scenario does this skill solve? What would the user say (trigger terms)?
   - Set `name`: `^[a-z0-9-]{1,64}$`, prefer `domain-action-object` (e.g. `ontrak-query-status`).
   - Decide the target directory: `skills/<category>/<name>/` (diagnosis `diagnose/`, operation `operate/`, or top level).

2. **Snapshot key parameters**: gather and record the fixed values you will use (device / channel / path / threshold) once up front and reuse them, to avoid repeated re-asking.

3. **Write `SKILL.md`** (use the template below). Key points:
   - Write `description` as a **router**: trigger terms + symptoms + scenarios; use `when_to_use` for complementary info.
   - Write the body as a **router**: what to do / order / interpretation / when to hand off to another skill. Keep it under 300 lines; if longer, split into `references/`.
   - Declare `allowed-tools` **on demand** (escalation gate): read-only diagnosis → `[read_file, search_files, run_shell]`;
     add `write_file`/`edit_file` only when writes are needed. Safe tools outside the list still work, while risky
     tools interrupt the flow to wait for user confirmation, so list everything you expect to use.
   - Declare `env` **only when it depends on a specific runtime** (dedicated CLI / local service / fixed path, e.g. `env: container`);
     for general skills (doc generation, pure knowledge Q&A) **leave it empty = any environment**. Once declared, an environment mismatch is hard-blocked when installing from an online repo.

4. **Split Tier-3 (on demand)**
   - Detail docs → `references/<topic>.md`, with one line in the body on "when to read which".
   - Fixed actions → `scripts/<action>.sh`, satisfying the four principles: **self-healing / structured output / idempotent / safety boundaries**.

5. **Persist**: use `write_file` to write `SKILL.md` (and `references/`, `scripts/` resources).
   - Note: the target directory must be within a writable `os_allow_roots`. If rejected, confirm the write location with the user first.

6. **Self-check (see Checklist below), then have the user reload the skill** (hot reload or restart), then `GET /api/skills` to see
   whether `diagnostics` has `parse_error`/`shadowed`/`lint` warnings, and fix them if so.

7. **Publishing to the Skills Hub (this repo)**: also set `category`, `author`, `icon` (a 256x256 PNG at
   `assets/icon.png`), and `public` in frontmatter, and optionally add a `CHANGELOG.md` at the skill root.
   Then run `node scripts/generate-skills.js` from the repo root to rebuild `public/skills.json`. See the
   "Skills Hub Publishing Fields" section in `references/skill-authoring.md` for details.

## SKILL.md Template

```markdown
---
name: <lower-hyphen-name>
description: <trigger terms + symptoms + scenarios, one line so the model knows when to pick it>
when_to_use: <when to use, complementary to description>
allowed-tools: [read_file, search_files]
version: 0.1.0
# Skills Hub publishing fields (this repo; see references/skill-authoring.md §7a):
category: tool                 # home-page grouping
author: Name <email or link>
icon: assets/icon.png          # 256x256 PNG
public: true                   # include in the public whitelist build
---

# <Title>

<Router body: goal / steps / interpretation / handoff>

## Interpretation
- <Result A> → <conclusion / hand off to some skill>

## Notes
- <pitfalls / safety boundaries / read-only vs needs confirmation>
```

## Checklist (verify each before delivery)

- [ ] `name` is valid (`^[a-z0-9-]{1,64}$`) and does not collide with an existing skill (avoid shadowed).
- [ ] `description` contains trigger terms and scenarios, not vague; `when_to_use` does not duplicate it.
- [ ] Body is a router, line count < 300 (hard limit 500); long detail moved into `references/`.
- [ ] `allowed-tools` is a minimal set (do not leave empty for skills with side effects).
- [ ] `env`: declare only when it depends on a specific runtime; leave empty for general skills (= any environment).
- [ ] Scripts (if any) satisfy self-healing / structured output / idempotent / safety boundaries.
- [ ] After reload, `/api/skills` `diagnostics` has no warnings for this skill.
- [ ] Skills Hub: `category` set, `icon` present (256x256 PNG), `public` set as intended, optional `CHANGELOG.md` added, and `generate-skills.js` re-run.

For details and complete field descriptions, always defer to `references/skill-authoring.md`.
