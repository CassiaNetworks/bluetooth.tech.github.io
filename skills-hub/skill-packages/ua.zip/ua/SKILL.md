---
name: ua
category: tool
description: Bundled ua command-line client (open62541 ua-cli) to browse, read/write, and verify any OPC UA server from the shell. Use when the user says "OPC UA won't connect / read a node / browse the address space / verify endpoint security policy / getting BadSecurityChecksFailed or BadNoMatch".
when_to_use: When you need to browse the address space, read or write nodes, or check an OPC UA server's endpoints and encryption/authentication config on a gateway or in a container without a GUI.
allowed-tools: [read_file, search_files, run_shell]
env: gateway, container
version: 1.2.0
author: Cassia Networks <https://www.cassianetworks.com>
icon: assets/icon.png
public: true
---

# ua — OPC UA command-line tool

The skill bundles the binary `scripts/ua` ([open62541](https://github.com/open62541/open62541) v1.5.5
`ua-cli` client, with mbedTLS, armv7 musl, fully static), which only runs on the gateway/container (ARM).
Run `chmod +x scripts/ua` before first use. Run `./scripts/ua --help` for the services and options; below are
only the non-obvious pitfalls.

## Minimal example

```bash
# First troubleshooting step: list endpoints (no session; any output means TCP is up; shows security policy and auth methods)
./scripts/ua opc.tcp://<host>:<port> getendpoints

# Read a node
./scripts/ua opc.tcp://<host>:<port> read 'ns=2;s=Some/Node'
```

## Non-obvious pitfalls

- **All `--` options must come before the URL** (open62541 ua-cli's argument parser): after the URL only the
  service name and its arguments are allowed. If the command prints usage and exits immediately, this is almost
  always why.
- **`BadNoMatch` on a browse path**: the leading number is the namespace index of the BrowseName (many servers
  create nodes with the BrowseName in ns 0, so write `0:`); and the starting point is already the Objects folder,
  so **don't write `/Objects` again**. When unsure, run `explore '/0:Xxx' --depth 2` to see the structure, or read
  by NodeId directly.
- **A None endpoint returns `BadSecurityChecksFailed` (log contains `nonce that is too short`)**: observed with
  some server implementations (e.g. async-opcua) that return an empty serverNonce under the None policy, which
  appears to violate OPC UA Part 4 §5.7.3; open62541 v1.5+ clients reject it per spec (UAExpert etc. don't
  validate, so it "works" there). This appears to be a server-side deviation; the workaround is to use an
  encrypted endpoint.
- **Certificates/private keys are DER only**; PEM fails to load. On a plaintext (None) channel the client refuses
  to send the password by default, so password auth must go over an encrypted endpoint. See `references/tls-certs.md`
  for a certificate-generation template.
- The ns index isn't guaranteed consistent across servers; read `i=2255` (NamespaceArray) to confirm, don't
  hard-code and reuse.
