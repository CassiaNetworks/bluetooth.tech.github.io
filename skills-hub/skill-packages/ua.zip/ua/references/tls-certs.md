# Encrypted-endpoint certificate template (DER)

`ua`'s `--certificate/--privatekey` **accept DER format only**. The application
instance certificate (for the encrypted channel) and the user identity
(`--username/--password`) are two separate things and can be combined independently.

## Client certificate (self-signed is fine)

```bash
cat > client.cnf <<'EOF'
[req]
distinguished_name = dn
req_extensions     = v3_req
x509_extensions    = v3_req
prompt             = no

[dn]
CN = ua-cli debug client

[v3_req]
basicConstraints   = critical, CA:FALSE
keyUsage           = critical, digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
extendedKeyUsage   = clientAuth, serverAuth
subjectAltName     = URI:urn:open62541.client.application
EOF
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 -config client.cnf \
  -keyout client.key -out client.crt
openssl x509 -in client.crt -outform DER -out client.der
openssl pkey -in client.key -outform DER -out client.key.der
```

The SAN `URI:urn:open62541.client.application` must match the client's
ApplicationUri (this is open62541's default); otherwise a server that validates
the URI will reject the handshake.

## Connecting

```bash
# Run from the skill root (the binary lives in scripts/)
./scripts/ua --username <user> --password '<pass>' \
  --certificate client.der --privatekey client.key.der \
  opc.tcp://<host>:<port> read 'ns=2;s=Some/Node'
```

Wrap the whole password in single quotes when it contains characters like `$`.
If you only need to verify the encrypted channel and the server allows anonymous
access, you can drop the username/password.

## When issuing a certificate for the server (peer-side config)

The OPC UA spec requires the server certificate's **SubjectAltName URI entry to
equal its ApplicationUri** (read `Server.ApplicationUri` from the `getendpoints`
output); most implementations enforce this strictly:

```
subjectAltName = URI:<the server's ApplicationUri>,IP:<server IP>
```

## Error reference

| Error | Cause |
|---|---|
| Certificate fails to load | You passed PEM; convert to DER |
| Handshake `BadSecurityChecksFailed` | Certificate not trusted / SAN URI doesn't match ApplicationUri (use `--loglevel 2` for details) |
| `Rejected, no matching UserTokenPolicy` | The endpoint doesn't offer that auth method (e.g. sending a password to a plaintext endpoint; the client's security default blocks it outright) |
