# Changelog

## 1.2.0 - 2026-07-16

- Recategorized as `tool` and repositioned as a general-purpose OPC UA command-line client (browse/read/write/verify), not debug-only.
- Translated `references/tls-certs.md` to English for consistency with the rest of the skill docs.
- Clarified pitfall wording: noted the `--`-before-URL rule is open62541 ua-cli's parser behavior, and framed the None-endpoint empty-nonce issue as an observed server-side deviation.

## 1.1.0 - 2026-07-16

- Rebuilt `scripts/ua` as a fully static armv7 musl binary with mbedTLS (open62541 v1.5.5).
- Documented the non-obvious pitfalls: `--` options must precede the URL, `BadNoMatch` namespace handling, and the None-endpoint `BadSecurityChecksFailed` server defect.
- Added `references/tls-certs.md` with a DER certificate-generation template.

## 1.0.0 - 2026-05-20

- Initial release: bundled ua (open62541 ua-cli) client for command-line OPC UA debugging.
