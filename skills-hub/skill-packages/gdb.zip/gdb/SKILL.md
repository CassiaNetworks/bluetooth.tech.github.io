---
name: gdb
category: debug
description: Bundled gdb debugger for the gateway, focused on live processes—attach to a running pid, capture a backtrace after a crash/segfault, or snapshot a hung/unresponsive process. Use when the user says "process crashed / segfault / stuck and not responding / no idea why it died / get a backtrace / attach to pid / dump the stack".
when_to_use: When you need to debug a process that is currently running on the gateway—attach by pid to grab a stack trace, inspect threads of a hung process, or take a core snapshot for offline analysis.
allowed-tools: [read_file, search_files, run_shell]
env: gateway
version: 1.0.0
author: Cassia Networks <https://www.cassianetworks.com>
icon: assets/icon.png
public: true
---

# gdb — live process debugger (gateway)

Bundled `scripts/gdb` (armhf, dynamically linked, **gateway only**). First use: `chmod +x scripts/gdb`.
If `./scripts/gdb --version` fails with a missing `.so`, the gateway lacks that runtime lib—stop and report it.

Environment-specific notes (standard gdb usage assumed):

- Always run non-interactively with `-batch`, or gdb sits at a prompt and hangs the shell:

```bash
./scripts/gdb -p <pid> -batch -ex "bt" -ex "thread apply all bt"
```

- Attach needs ptrace rights (same user as target, or root); a non-zero `ptrace_scope` can block it.
- For long analysis, snapshot with `gcore` instead of holding a production process frozen:

```bash
./scripts/gdb -p <pid> -batch -ex "gcore /tmp/proc.core"   # process keeps running
./scripts/gdb -c /tmp/proc.core -batch -ex "bt"
```
