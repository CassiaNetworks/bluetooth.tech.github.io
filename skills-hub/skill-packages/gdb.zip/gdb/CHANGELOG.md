# Changelog

## 1.0.0 - 2026-07-17

- Initial release: bundled armhf `gdb` for the gateway, focused on live process debugging (attach by pid, backtraces, `gcore` snapshots).
- Note: the binary is dynamically linked (`ld-linux-armhf.so.3`) and relies on the gateway's own glibc/ncurses runtime; it only runs on the gateway.
- Documented the non-obvious pitfalls: mandatory `-batch` for scripting, ptrace permission (`ptrace_scope`), stripped-target backtraces, and snapshotting with `gcore` to avoid freezing production processes.
