# Changelog

## 1.2.0 - 2026-07-16

- Recategorized as `tool` and repositioned as a general-purpose Modbus TCP command-line client (read/write/verify), not debug-only.
- Removed RTU/serial positioning: RTU is not supported in this deployment; the skill now targets Modbus TCP only.
- Corrected the slave-address pitfall: unit id `0` is broadcast/reserved in Modbus (TCP-to-RTU gateways often remap it to slave `1`), and `-Q` (MAX_SLAVE quirk) is needed to allow the full `0-255` range.

## 1.1.0 - 2026-07-16

- Rebuilt `scripts/mbpoll` as a fully static armv7 musl binary (no system library dependencies).
- Documented the non-obvious pitfalls: reversed `-t` function-code mapping, addressing base (`-0`), and 32-bit word order (`-B`).
- Clarified RTU limitations (standard baud rates only; TCP recommended for link verification).

## 1.0.0 - 2026-05-20

- Initial release: bundled mbpoll client for command-line Modbus TCP/RTU debugging.
