---
name: mbpoll
category: tool
description: Bundled mbpoll command-line client for reading, writing, and verifying any Modbus TCP slave (coils and registers) from the shell. Use when the user says "Modbus reads nothing / values are all zero / register addresses don't line up / verify port 502 / read or write coils and registers".
when_to_use: When you need to read, write, or verify Modbus TCP coils and registers from the command line on a gateway or in a container—checking slave address, addressing base (0- vs 1-based), or 32-bit byte/word order.
allowed-tools: [read_file, search_files, run_shell]
env: gateway, container
version: 1.2.0
author: Cassia Networks <https://www.cassianetworks.com>
icon: assets/icon.png
public: true
---

# mbpoll — Modbus TCP command-line tool

The skill bundles the binary `scripts/mbpoll` ([epsilonrt/mbpoll](https://github.com/epsilonrt/mbpoll) v1.5.4,
armv7 musl, fully static, no system libraries), which only runs on the gateway/container (ARM). Run
`chmod +x scripts/mbpoll` before first use. Run `./scripts/mbpoll -h` for the full option list; below are only the non-obvious pitfalls.

## Minimal example

```bash
# Read 3 holding registers from slave 1 at <host>:502 (PDU address base 0), read once and exit
./scripts/mbpoll -m tcp -a 1 -0 -r 0 -c 3 -1 <host>
```

## Non-obvious pitfalls

- **The `-t` numbers are the reverse of the classic Modbus function codes** (intentional by the author): `-t 3`
  is input registers (FC04), `-t 4` is holding registers (FC03, the default). Don't pick by FC number intuition.
- **Two main causes of all-zero / off-by-one reads**:
  - The slave address defaults to `-a 1`; set it explicitly if the target differs. Over Modbus TCP the unit id is
    often ignored, but many TCP-to-RTU gateways remap unit id `0` to serial slave `1`. mbpoll limits the slave-id
    range by default—pass `-Q` (MAX_SLAVE quirk) to allow the full `0-255` range.
  - `-r` defaults to 1-based numbering; add `-0` for 0-based PDU addresses. Device docs in 4xxxx style use
    1-based; protocol addresses use `-0`.
- **32-bit values (`-t 4:int` / `4:float`) span 2 registers**, and word order has no universal standard: if the
  magnitude looks wildly off, add `-B` (high word first) and read again.
- Writing = put the value right after `host` (prefix negative numbers with `--` as a separator); an `Illegal function`
  reply from the peer means the function code is unsupported or read-only — that's peer behavior.
- Always pass `-1` when scripting, otherwise it keeps polling and won't exit.
